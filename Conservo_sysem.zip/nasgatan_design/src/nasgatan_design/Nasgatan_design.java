
package nasgatan_design;


public class Nasgatan_design {

   
    public static void main(String[] args) {
       
    }
    
}
